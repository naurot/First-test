public class MenuItem extends Decorator {
    // an item on the menu - either appetizer, main course, or dessert
    // has a cost
    // made up of ingredients
    // ingredients are Decorators of the dish
    private String description;
    private String cost;
    private int itemNumber;
    private static int num = 0;

    public MenuItem(String description, String price) {
        this.description = description;
        cost = price;
        itemNumber = num++;
    }

    @Override
    public void printItem() {
        System.out.println(this);
    }

    public MenuItem getItem() {
        return this;
    }

    public Double getPrice() {
        return Double.parseDouble(cost);
    }

    public String toString() {
        return description + "\t\t$" + getPrice();
    }

    public int getItemNumber() {
        return itemNumber;
    }
}
