import java.util.ArrayList;

public class DisplayTab implements Command {
    private ArrayList<String> tab = new ArrayList<>();
 //   private ArrayList<MenuItem> menu;  // to come from aggregator, use getter in aggregator
    private ArrayList<OrderItem> orders;
    private double total = 0;

    public DisplayTab(ArrayList<Decorator> menu, ArrayList<OrderItem> orders){
        System.out.println("\n\nTab\n---");
        for (OrderItem item : orders) {
            Decorator tmp = menu.get(item.getItemNum());
            MenuItem miTmp = tmp.getItem();
            tab.add(miTmp.toString());
            total = total + miTmp.getPrice();
        }
    }

    @Override
    public void execute() {
        for (String item : tab) {
            System.out.println(item);
        }
        System.out.format("Total: %.2f", total);
    }
}
