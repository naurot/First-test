import java.util.ArrayList;

public class SystemInterface {
    static ArrayList<MenuItem> menu = new ArrayList<>();
    static ArrayList<OrderItem> orders = new ArrayList<>();

    public void displayMenu(){
        Invoker invoker = new Invoker();
        Command displayMenu = new DisplayMenu();
        invoker.setCommand(displayMenu);
        invoker.doCommand();
    }

    public void getOrder(){
        Invoker invoker = new Invoker();
        Command submitOrder = new SubmitOrder();
        invoker.setCommand(submitOrder);
        invoker.doCommand();
    }

    public void displayTab(){
        Invoker invoker = new Invoker();
        Command displayTab = new DisplayTab(Menu.getMenu(), Orders.getOrders());
        invoker.setCommand(displayTab);
        invoker.doCommand();
    }
}
