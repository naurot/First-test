import java.util.ArrayList;

public class SubmitOrder implements Command {
    private ArrayList<OrderItem> orders = new ArrayList<>();

    public SubmitOrder(){
        OrderItem orderedItem;
        do {
            orderedItem = new OrderItem();
            orderedItem.getOrderItemNum();
            if (orderedItem.getItemNum() != -1)
                orders.add(orderedItem);
        } while (orderedItem.getItemNum() != -1);
    }
    @Override
    public void execute() {
        Orders tmp = new Orders(orders);
        orders = tmp.getOrders();
    }
}
