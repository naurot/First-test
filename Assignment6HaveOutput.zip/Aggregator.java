import java.util.ArrayList;

public class  Aggregator {
    static ArrayList<Decorator> menu;
    static ArrayList<OrderItem> items;



    public int getItem(){
        return 1;
    }
}
