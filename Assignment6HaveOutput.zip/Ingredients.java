public class Ingredients extends Decorator {
 //   Decorator item;
 //   String ingredient;

    public Ingredients(String ingredient, Decorator item) {
        super(ingredient, item);
    }

    public void printItem(){
        super.printItem();
    }

    @Override
    public Double getPrice() {
        return item.getPrice();
    }
}
