import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Orders {
    ArrayList<OrderItem> orders = new ArrayList<>();
    {

    }
}
