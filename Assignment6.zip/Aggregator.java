public class Aggregator {

    Menu menu;
    Orders orders;

}
