public class DisplayMenu implements Command{
    @Override
    public void execute() {
    }
}
