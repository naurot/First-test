public class DisplayTab implements Command{
    @Override
    public void execute() {

    }
}
