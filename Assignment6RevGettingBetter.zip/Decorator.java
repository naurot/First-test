public abstract class Decorator {
    Decorator item;
    String ingredient;
    boolean lastIngredient = true;

    public Decorator() {

    }

    public Decorator(String ingredient, Decorator item) {
        this.ingredient = ingredient;
        this.item = item;
        this.item.lastIngredient = false;
    }

    public void printItem() {
        item.printItem();
        System.out.print(item instanceof MenuItem ? "\t" : ", ");
        System.out.print(ingredient);
        if (lastIngredient)
            System.out.println();
    }

    public MenuItem getItem(){
        return item.getItem();
    }

    public abstract Double getPrice();
}
