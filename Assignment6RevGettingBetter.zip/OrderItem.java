import java.util.Scanner;

public class OrderItem {
    private int itemNum;

    public int getOrderItemNum() {
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter Selection, [-1] to End: ");
        itemNum = cin.nextInt();
        cin.nextLine();
        return itemNum;
    }
    public int getItemNum(){
        return itemNum;
    }
}
