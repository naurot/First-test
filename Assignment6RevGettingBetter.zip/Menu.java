import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Menu {
    // menu consists of appetizers, main courses, and desserts
    // each menu is personalized for each customer by way of a factory
    private static ArrayList<Decorator> menu = new ArrayList<>();
    Decorator menuItem;

    private Menu() { //Singleton
        //       menu.add(new MenuItem(new Ingredients("Carrots", new Ingredients("Peas", new Ingredients("Potatoes",
        //               new Ingredients("Rump Roast", new MenuItem("Pot Roast", "17.99")))))));
        menuItem = new Ingredients("Sardines", new Ingredients("Parmesan Cheese",
                new Ingredients("Romaine Lettuce", new MenuItem("Caesar Salad", "12.99"))));
        menu.add(menuItem);
        menuItem = new Ingredients("Sardines", new Ingredients("Eggs",
                new Ingredients("Iceberg Lettuce", new MenuItem("Salad Nicoise", "14.99"))));
        menu.add(menuItem);
        menuItem = new Ingredients("Carrots", new Ingredients("Peas", new Ingredients("Potatoes",
                new Ingredients("Rump Roast", new MenuItem("Pot Roast", "17.99")))));
        menu.add(menuItem);
        menuItem = new Ingredients("Black Pepper", new Ingredients("Mushrooms",
                new Ingredients("Steak", new MenuItem("Steak au Poivre", "23.99"))));
        menu.add(menuItem);
        menuItem = new Ingredients("Capers", new Ingredients("Onions", new Ingredients("Egg Yolk",
                new Ingredients("Ground Beef", new MenuItem("Steak Tartare", "18.99")))));
        menu.add(menuItem);
        menuItem = new Ingredients("Walnuts", new Ingredients("Honey",
                new Ingredients("Phyllo", new MenuItem("Baklava", "7.99"))));
        menu.add(menuItem);
        menuItem = new Ingredients("Vanilla", new Ingredients("Cane Sugar",
                new Ingredients("Heavy Cream", new MenuItem("Creme Brulee", "8.99"))));
        menu.add(menuItem);
        menuItem = new Ingredients("Strawberries", new Ingredients("Blueberries", new Ingredients("Raspberries",
                new Ingredients("Shortbread Crust", new MenuItem("Mixed Berry Pie", "7.99")))));
        menu.add(menuItem);
    }

    public static ArrayList<Decorator> getMenu() {
        if (menu.size() == 0)
            new Menu();
        return menu;
    }

    public static ArrayList<MenuItem> getMenuDescription() {
        ArrayList<MenuItem> retMenu = new ArrayList<>();
        for (Decorator menuItem : menu) {
           retMenu.add(menuItem.getItem());
        }
        return retMenu;
    }
}