import java.util.ArrayList;

public class Orders{
    private static ArrayList<OrderItem> orders = new ArrayList<>();
    public Orders(ArrayList<OrderItem> orders){
        if (this.orders.size() == 0)
            this.orders = new ArrayList<>();
        for (OrderItem order : orders)
            this.orders.add(order);
    }
    public static ArrayList<OrderItem> getOrders(){
        return orders;
    }

}
