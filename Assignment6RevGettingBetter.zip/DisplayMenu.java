import java.util.ArrayList;

public class DisplayMenu implements Command {
    private ArrayList<Decorator> menu;

    public DisplayMenu() {
        menu = Menu.getMenu();
    }

    @Override
    public void execute() {
        for (int i = 0; i < menu.size(); i++) {
            System.out.print("[" + i + "]");
            menu.get(i).printItem();
        }
    }
}
