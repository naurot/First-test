public interface Rebate {   // marker interface, i.e., nothing to implement
}

