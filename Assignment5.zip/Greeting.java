public interface Greeting {
}
