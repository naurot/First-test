public interface Coupon {   // marker interface, i.e., nothing to implement
}

