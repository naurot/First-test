public interface SecondaryHeading {   // marker interface, i.e., nothing to implement
}

